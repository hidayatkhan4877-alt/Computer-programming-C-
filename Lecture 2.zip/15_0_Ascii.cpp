
#include <iostream>
#include <cmath> 
#include <iomanip>

using namespace std;

int main()
    {
	cout << "The character (" << 'a' << ") has the value "      << static_cast< int > ( 'a' ) << endl; 



    return 0;   
    } 

