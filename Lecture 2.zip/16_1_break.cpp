
#include <iostream>
#include <cmath> 
#include <iomanip>

using namespace std;

int main()
    {
       int x;  // x declared here so it can be used after the loop
    
       // loop 10 times
       for ( x = 1; x <= 10; x++ ) {
    
          // if x is 5, terminate loop
          if ( x == 5 )
             break;           // break loop only if x is 5
    
          cout << x << " ";   // display value of x
    
       } // end for 


    return 0;   
    } 

