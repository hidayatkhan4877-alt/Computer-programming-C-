
#include <iostream>
using namespace std;

int main()
    {
    int grade = 0;
    cout <<"Enter grade for student"<< endl;
    cin >> grade; 
    
	if ( grade >= 90 )       // 90 and above   
		cout << "A";
	else if ( grade >= 80 )  // 80-89  
		cout << "B";
	else if ( grade >= 70 )  // 70-79
		cout << "C"; 
	else if ( grade >= 60 )  // 60-69
		cout << "D";
	else                     // less than 60   
		cout << "F";


    return 0;   
    } 

