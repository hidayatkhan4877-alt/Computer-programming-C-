
#include <iostream>
using namespace std;

int main()
    {
    int d = 10, e= 5, f = 90, g = 92;
    
    cout<< "d-- : " << d-- << endl;
    d = d-1    ;  
    cout<< "d = d-1: " << d<<endl;
	
	cout<< "--d:  " << --d <<endl;

    return 0;   
    } 

