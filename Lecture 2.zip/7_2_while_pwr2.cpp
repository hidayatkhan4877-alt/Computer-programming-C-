
#include <iostream>
using namespace std;

int main()
    {
	int product = 1;
	cout<< "-------------------------------"<<endl;
	cout<<"\t  Power of 2"<<endl;
	cout<<"________________________________"<<endl;
	while ( product <= 1024 )
		{
		product = 2 * product;
	    cout<< product<<endl;
		}	   
	cout<<"________________________________";
	   
    return 0;   
    } 

