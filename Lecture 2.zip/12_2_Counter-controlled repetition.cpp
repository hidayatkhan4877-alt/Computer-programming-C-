
#include <iostream>
using namespace std;

int main()
    {
    int counter = 10;             // initialization
    
    while ( counter >= 1 ) 
		{   // repetition condition
        cout << counter << endl;  // display counter
        --counter;                // increment
        } // end while 


    return 0;   
    } 

