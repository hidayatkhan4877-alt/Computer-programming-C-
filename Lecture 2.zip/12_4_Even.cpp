
#include <iostream>
using namespace std;

int main()
    {
    int counter = 2;             // initialization
    
    while ( counter <= 10 ) 
		{   // repetition condition
        cout << counter << endl;  // display counter
        counter += 2;                // increment
        } // end while 


    return 0;   
    } 

