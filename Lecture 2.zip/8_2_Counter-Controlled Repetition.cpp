#include <iostream>
#include <iomanip>        
using namespace std;
int main()
    {
    int total;         // sum of grades
    int gradeCounter;  // number of grades entered
    int grade;         // grade value
    
    double average;    // number with decimal point for average
    
       // initialization phase
    total = 0;         // initialize total
    gradeCounter = 0;  // initialize loop counter
    	// processing phase
       // get first grade from user
    cout << "Enter grade, -1 to end: ";  // prompt for input
    cin >> grade;                        // read grade from user

       // loop until sentinel value read from user
    while ( grade != -1 ) 
		{                  
        total = total + grade;            // add grade to total
        gradeCounter = gradeCounter + 1;  // increment counter 
        cout << "Enter grade, -1 to end: ";  // prompt for input
        cin >> grade;                        // read next grade
       } // end while
    
       // termination phase
       // if user entered at least one grade ...
       if ( gradeCounter != 0 ) 
			{
         // calculate average of all grades entered
          average = static_cast< double >( total ) / gradeCounter;
          // display average with two digits of precision
          cout << "Class average is " << setprecision( 2 )
               << fixed << average << endl;
       		} // end if part of if/else
    
       else // if no grades were entered, output appropriate message
          cout << "No grades were entered" << endl;
   
       return 0;   // indicate program ended successfully
    
    } // end function main

