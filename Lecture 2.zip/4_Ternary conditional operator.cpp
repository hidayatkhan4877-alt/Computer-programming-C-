
#include <iostream>
using namespace std;

int main()
    {
    int grade = 0;
    cout <<"Enter grade for student"<< endl;
    cin >> grade; 
    
	cout << ( grade >= 60 ? "Passed" : "Failed" );

    return 0;   
    } 

