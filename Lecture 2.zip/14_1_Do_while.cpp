
#include <iostream>
#include <cmath> 
#include <iomanip>

using namespace std;

int main()
    {
       int counter = 1;              // initialize counter
    
       do {                        
          cout << counter << endl;  // display counter
        ++counter; 
       } while ( counter <= 10 );  // end do/while 
    
       cout << endl;


    return 0;   
    } 

