
#include <iostream>
using namespace std;

int main()
    {
    int d = 10, e= 20, f = 30, g = 40;
    
    cout<< "before -> d : " << d << endl;
    d -= 4  ;   
    cout<< "After -> d -= 4: " << d<<endl;
	d = d - 4;
	cout<< "After -> d = d - 4:  " << d <<endl;
	e *= 5   ;  
	e = e * 5;
	f /= 3   ;  
	f = f / 3;
	g %= 9     ;
	g = g % 9;

    

    return 0;   
    } 

