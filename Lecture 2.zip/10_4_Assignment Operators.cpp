
#include <iostream>
using namespace std;

int main()
    {
    int d = 10, e= 5, f = 90, g = 92;
    
    cout<< "before -> g : " << g << endl;
    g %= 9     ;  
    cout<< "After -> g %= 9: " << g<<endl;
	g = g % 9;
	cout<< "After -> g = g % 9;:  " << g <<endl;

    return 0;   
    } 

