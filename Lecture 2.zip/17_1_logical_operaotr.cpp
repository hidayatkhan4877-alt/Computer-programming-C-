#include <iostream>
using namespace std;

int main() {
    int a, b;
    cout << "Enter two integers: ";
    cin >> a >> b;

    // Equal to (==) and Not equal to (!=)
    if (a == b) 
		{
        cout << "a and b are equal." << endl;
    	} 
	else if (a != b) 
		{
        cout << "a and b are not equal." << endl;
    	}

    // Logical AND (&&)
    if (a > 0 && b > 0) 
		{
        cout << "Both numbers are positive." << endl;
    	}

    // Logical OR (||)
    if (a < 0 || b < 0) 
		{
        cout << "At least one number is negative." << endl;
    	}

    return 0;
}

