
#include <iostream>
using namespace std;

int main()
    {
    int grade = 0;
    cout <<"Enter grade for student"<< endl;
    cin >> grade; 
    
    
	if ( grade >= 60 )
		cout << "Passed";
	else
		cout << "Failed";

    return 0;   
    } 

