
#include <iostream>
using namespace std;

int main()
    {
       // Initialization, repetition condition and incrementing 
       // are all included in the for structure header. 
    
       for ( int counter = 10; counter >= 1; counter-- )
          cout << counter << endl;                      



    return 0;   
    } 

