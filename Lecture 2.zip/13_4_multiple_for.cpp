
#include <iostream>
using namespace std;

int main()
    {
    int sum = 0;                       
	// sum even integers from 2 through 100
	for ( int number = 2; number <= 10; number += 2 )     
	    sum += number;                  // add number to sum
	    
	cout << "Sum is " << sum << endl;  
    return 0;   
    } 

