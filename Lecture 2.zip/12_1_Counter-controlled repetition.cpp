
#include <iostream>
using namespace std;

int main()
    {
    int counter = 1;             // initialization
    
    while ( counter <= 10 ) 
		{   // repetition condition
        cout << counter << endl;  // display counter
        ++counter;                // increment
        } // end while 


    return 0;   
    } 

