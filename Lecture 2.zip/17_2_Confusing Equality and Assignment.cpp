#include <iostream>
using namespace std;

int main() 
	{
	int payCode = 3;
	if ( payCode == 4 )
		cout << "You get a bonus!" << endl;

    return 0;
}

