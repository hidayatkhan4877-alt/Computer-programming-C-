
#include <iostream>
using namespace std;

int main()
    {
    int num = 5;

    
	if ( num )
		cout << "Zero mean False \n\nand Non zero mean true."; 

    return 0;   
    } 

