
#include <iostream>
using namespace std;

int main()
    {
	int product = 2;
	while ( product <= 1000 )
	   product = 2 * product;
	   
    return 0;   
    } 

