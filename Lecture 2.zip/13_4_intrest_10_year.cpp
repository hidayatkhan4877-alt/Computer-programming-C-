
#include <iostream>
#include <cmath> 
#include <iomanip>

using namespace std;

int main()
    {
       double amount;              // amount on deposit
       double principal = 1000.0;  // starting principal
       double rate = .05;          // interest rate
              // output table column heads
       cout << "Year" << setw( 21 ) << "Amount on deposit" << endl;
    
       // set floating-point number format
       cout << fixed << setprecision( 2 ); 
    
       // calculate amount on deposit for each of ten years
       for ( int year = 1; year <= 10; year++ ) {
    
          // calculate new amount for specified year
          amount = principal * pow( 1.0 + rate, year );
    
         // output one table row
          cout << setw( 4 ) << year            
               << setw( 21 ) << amount << endl;
    
       } // end for 


    return 0;   
    } 

