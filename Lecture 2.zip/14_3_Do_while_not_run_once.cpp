
#include <iostream>
#include <cmath> 
#include <iomanip>

using namespace std;

int main()
    {
       int counter = 1;              // initialize counter
    
        while ( counter > 10 ) {                        
          cout << counter << endl;  // display counter
        ++counter; 
       };  // end do/while 
    
       cout << endl;


    return 0;   
    } 

